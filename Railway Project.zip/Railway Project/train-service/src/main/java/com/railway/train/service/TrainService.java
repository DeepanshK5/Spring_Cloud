package com.railway.train.service;

import com.railway.train.entity.Train;
import com.railway.train.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class TrainService {

    @Autowired
    private TrainRepository trainRepository;

    public Train saveTrain(Train train) {
        return trainRepository.save(train);
    }

    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    public List<Train> searchTrain(String source, String destination, LocalDate travelDate) {
        return trainRepository.findBySourceAndDestinationAndTravelDate(source, destination,travelDate);
    }

    public Optional<Train> getTrainById(Long id){
        return trainRepository.findById(id);
    }

    public void deleteTrain(Long id){
        trainRepository.deleteById(id);
    }

    public Train updateAvailableSeats(Long trainId,int count){
        Train train = trainRepository.findById(trainId)
                .orElseThrow(
                        () -> new RuntimeException("Train not Found")
                );
        int updatedSeats = train.getAvailableSeats()+count;

        if(updatedSeats<0){
            throw new RuntimeException("Not enough seats are available");
        }
        train.setAvailableSeats(updatedSeats);
        return trainRepository.save(train);
    }
}
