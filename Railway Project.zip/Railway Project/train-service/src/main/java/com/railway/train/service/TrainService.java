package com.railway.train.service;

import com.railway.train.entity.Train;
import com.railway.train.external.StationServiceClient;
import com.railway.train.model.Station;
import com.railway.train.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class TrainService {

    @Autowired
    private StationServiceClient stationServiceClient;

    @Autowired
    private TrainRepository trainRepository;

    public Train saveTrain(Train train) {

        List<Station> fullStations = train.getStationList().stream()
                .map(s ->
                        stationServiceClient.getStationById(s.getId())
                        .orElseThrow(() -> new RuntimeException("Station not found with ID: " + s.getId())))
                .toList();

        List<Station> stationStream = fullStations.stream().map(
                x -> {
                    Station stationById = stationServiceClient.getStationById(x.getId()).get();
                    x.setStationCode(stationById.getStationCode());
                    x.setStationName(stationById.getStationName());
                    return x;
                }
        ).toList();

        double baseFare=0;

        for(Station s:stationStream){
            baseFare += (int) (50+(Math.random() * 100));
            s.setFareTillThis(baseFare);
        }
        stationStream.get(0).setFareTillThis(0);

        train.setStationList(stationStream);

        return trainRepository.save(train);
    }


    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    public List<Train> searchTrain(String sourceCode, String destinationCode, LocalDate travelDate) {
        List<Train> allTrains = trainRepository.findAll();

        List<Train> matchingTrains = allTrains.stream().filter(x->x.getTravelDate().equals(travelDate))
                .filter(train -> {
                    List<Station> stations = train.getStationList();

                    int sourceIndex = -1;
                    int destinationIndex = -1;

                    for (int i = 0; i < stations.size(); i++) {
                        String code = stations.get(i).getStationCode();

                        if (code.equalsIgnoreCase(sourceCode)) {
                            sourceIndex = i;
                        }
                        if (code.equalsIgnoreCase(destinationCode)) {
                            destinationIndex = i;
                        }
                    }

                    return sourceIndex != -1 &&
                            destinationIndex != -1 &&
                            sourceIndex < destinationIndex;
                })
                .collect(Collectors.toList());

        if (matchingTrains.isEmpty()) {
            throw new RuntimeException("No trains found for this route: " + sourceCode + " to " + destinationCode);
        }

        return matchingTrains;
    }


    public Optional<Train> getTrainById(Long id){
        return trainRepository.findById(id);
    }

    public void deleteTrain(Long id){
        trainRepository.deleteById(id);
    }

    public Train updateAvailableSeats(Long trainId,int count){
        Train train = trainRepository.findById(trainId)
                .orElseThrow(
                        () -> new RuntimeException("Train not Found")
                );
        int updatedSeats = train.getAvailableSeats()+count;

        if(updatedSeats<0){
            throw new RuntimeException("Not enough seats are available");
        }
        train.setAvailableSeats(updatedSeats);
        return trainRepository.save(train);
    }

}
