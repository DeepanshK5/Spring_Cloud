package com.railway.train.controller;

import com.railway.train.entity.Train;
import com.railway.train.service.TrainService;
import jakarta.validation.Valid;
import jakarta.ws.rs.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/trains")
public class TrainController {

    @Autowired
    private TrainService trainService;

    @PostMapping
    public ResponseEntity<Train> addTrain(@Valid @RequestBody Train train) {
        return ResponseEntity.ok(trainService.saveTrain(train));
    }

    @GetMapping
    public ResponseEntity<List<Train>> getAll() {
        return ResponseEntity.ok(trainService.getAllTrains());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Train>> getByRoute(@RequestParam String source, @RequestParam String destination, @RequestParam String date) {
        return ResponseEntity.ok(trainService.searchTrain(source, destination, LocalDate.parse(date)));
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Train> getTrainById(@PathVariable Long id){
        Train trainById = trainService.getTrainById(id).orElseThrow(
                () -> new RuntimeException("Error in geeTrainById")
        );
        return new ResponseEntity<>(trainById, HttpStatus.OK);
    }

    @PutMapping("/update-seats/{id}")
    public ResponseEntity<Train> updateSeats(
            @PathVariable Long id,
            @RequestParam int count
    ){
        try{
            Train updatedTrain = trainService.updateAvailableSeats(id,count);
            return ResponseEntity.ok(updatedTrain);
        }catch(RuntimeException e){
            return new ResponseEntity<>(new Train(),HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTrainById(@PathVariable Long id){
        Train trainById = trainService.getTrainById(id).orElseThrow(
                () -> new RuntimeException("Train not found with id: "+id)
        );
        trainService.deleteTrain(id);
        return ResponseEntity.ok("Train Deleted Successfully");
    }
}
