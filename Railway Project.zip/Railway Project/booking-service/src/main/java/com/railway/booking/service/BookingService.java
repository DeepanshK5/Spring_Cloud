package com.railway.booking.service;

import com.railway.booking.entity.Booking;
import com.railway.booking.external.TrainServiceClient;
import com.railway.booking.model.Train;
import com.railway.booking.repository.BookingRepository;
import feign.FeignException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.server.servlet.OAuth2AuthorizationServerProperties;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private TrainServiceClient trainServiceClient;

    public Booking bookTicket(Booking booking) {
        Train train;
        try{
            train = trainServiceClient.getTrainById(booking.getTrainId());
        }catch(FeignException.NotFound e){
            throw new RuntimeException("Train not Found with Id: "+booking.getTrainId());
        }
        if(train.getAvailableSeats()<booking.getSeatsBooked()){
            throw new RuntimeException("Booking seats more than available seats");
        }

        trainServiceClient.updateSeats(booking.getTrainId(),-booking.getSeatsBooked());
        booking.setPnr(UUID.randomUUID().toString().substring(0,8));

        booking.setTravelDate(train.getTravelDate());
        booking.setDestination(train.getDestination());
        booking.setSource(train.getSource());
        booking.setFare(train.getFare()* booking.getSeatsBooked());
        return bookingRepository.save(booking);
    }

    public Optional<Booking> cancelTicket(String pnr) {
        Optional<Booking> bookingOtp = bookingRepository.findByPnr(pnr);
        bookingOtp.ifPresent(booking -> {
            trainServiceClient.updateSeats(booking.getTrainId(),booking.getSeatsBooked());
            bookingRepository.delete(booking);
        });
        return bookingOtp;
    }

}
