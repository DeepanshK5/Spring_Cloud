package com.railway.booking.controller;

import com.railway.booking.entity.Booking;
import com.railway.booking.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<Booking> book(@RequestBody Booking booking) {
        return ResponseEntity.ok(bookingService.bookTicket(booking));
    }

    @DeleteMapping("/{pnr}")
    public ResponseEntity<?> cancel(@PathVariable String pnr) {
        Optional<Booking> booking = bookingService.cancelTicket(pnr);
        if (booking.isPresent()) {
            return ResponseEntity.ok("Booking cancelled for PNR: " + pnr);
        } else {
            return ResponseEntity.badRequest().body("PNR not found");
        }
    }
}
