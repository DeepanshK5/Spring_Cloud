package com.railway.gateway_service.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
public class AuthenticationFilter implements WebFilter {

    @Value("${jwt.secret}")
    private String secret;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String path = exchange.getRequest().getPath().toString();

        if (path.contains("/login") || path.contains("/register")) {
            return chain.filter(exchange); // public endpoints
        }

        // Add Swagger URLs to public access
        if (path.contains("/v3/api-docs") || path.contains("/swagger-ui") || path.contains("/swagger-ui.html")) {
            return chain.filter(exchange);
        }

        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            exchange.getResponse().setStatusCode(org.springframework.http.HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        String token = authHeader.substring(7);
        Claims claims;
        try {
            claims = Jwts.parser()
                    .setSigningKey(secret)
                    .parseClaimsJws(token)
                    .getBody();
        } catch (ExpiredJwtException ex) {
            // ❌ Token is expired
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            exchange.getResponse().getHeaders().add("Error-Message", "Token expired");
            return exchange.getResponse().setComplete();
        } catch (Exception e) {
            // ❌ Any other token error
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        // 🟢 Inject email and role as headers to pass to downstream services
        String email = claims.getSubject(); // user email
        String role = claims.get("role", String.class); // user role

//         🔒 Restrict Admin-Only Endpoints
//        if (
//                (path.contains("/admin") )
//                        && !"ADMIN".equals(role)
//        ) {
//            exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
//            exchange.getResponse().getHeaders().add("Error-Message", "Access Denied: Admin only");
//            return exchange.getResponse().setComplete();
//        }

        // 🛠️ Create a new request with mutated headers
        ServerWebExchange mutatedExchange = exchange.mutate()
                .request(builder -> builder
                        .header("X-User-Email", email)
                        .header("X-User-Role", role != null ? role : "USER") // default USER
                )
                .build();

        // ✅ Continue with the mutated request
        return chain.filter(mutatedExchange);
    }
}
