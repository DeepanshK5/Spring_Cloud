package com.railway.gateway_service.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.*;


@Component
public class AuthenticationFilter implements WebFilter {

    @Value("${jwt.secret}")
    private String secret;

    // Role-based access control map
    private static final Map<String, List<EndpointAccess>> roleAccessMap = new HashMap<>();

    static {
        roleAccessMap.put("USER", List.of(
                new EndpointAccess("/api/trains", HttpMethod.GET),
                new EndpointAccess("/api/trains/search", HttpMethod.GET),
                new EndpointAccess("/api/trains/id", HttpMethod.GET),
                new EndpointAccess("/api/station", HttpMethod.GET),
                new EndpointAccess("/api/station/code", HttpMethod.GET),
                new EndpointAccess("/api/station/id", HttpMethod.GET),
                new EndpointAccess("/api/bookings", HttpMethod.POST),
                new EndpointAccess("/api/bookings/pnr", HttpMethod.GET)
        ));
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String path = exchange.getRequest().getPath().toString();
        HttpMethod method = exchange.getRequest().getMethod();

        if (path.contains("/login") || path.contains("/register") ||
                path.contains("/v3/api-docs") || path.contains("/swagger-ui")) {
            return chain.filter(exchange);
        }

        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            exchange.getResponse().setStatusCode(org.springframework.http.HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        String token = authHeader.substring(7);
        Claims claims;
        try {
            claims = Jwts.parser()
                    .setSigningKey(secret)
                    .parseClaimsJws(token)
                    .getBody();
        } catch (ExpiredJwtException ex) {
            // ❌ Token is expired
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            exchange.getResponse().getHeaders().add("Error-Message", "Token expired");
            return exchange.getResponse().setComplete();
        } catch (Exception e) {
            // ❌ Any other token error
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        // 🟢 Inject email and role as headers to pass to downstream services
        String email = claims.getSubject(); // user email
        String role = claims.get("role", String.class); // user role


        // 🛠️ Create a new request with mutated headers
        ServerWebExchange mutatedExchange = exchange.mutate()
                .request(builder -> builder
                        .header("X-User-Email", email)
                        .header("X-User-Role", role != null ? role : "USER") // default USER
                )
                .build();

        // 🔒 Check if role is allowed to access this endpoint
        if (Objects.equals(role, "USER") &&!isAccessAllowed(role, path, method)) {
            System.out.println("Bro Access Is Not Allowed");
            exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
            exchange.getResponse().getHeaders().add("Content-Type", "application/json");

            String message = "{\"error\": \"Access Denied\", \"message\": \"You do not have permission to access this resource.\"}";
            byte[] bytes = message.getBytes(StandardCharsets.UTF_8);

            return exchange.getResponse().writeWith(Mono.just(exchange.getResponse()
                    .bufferFactory()
                    .wrap(bytes)));

        }


        // ✅ Continue with the mutated request
        return chain.filter(mutatedExchange);
    }

    private boolean isAccessAllowed(String role, String path, HttpMethod method) {
        List<EndpointAccess> allowedEndpoints = roleAccessMap.getOrDefault(role, Collections.emptyList());
        return allowedEndpoints.stream().anyMatch(endpoint ->
                path.startsWith(endpoint.path()) && method.equals(endpoint.method()));
    }

    private record EndpointAccess(String path, HttpMethod method) {}

}
