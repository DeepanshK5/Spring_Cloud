package com.railway.payment.service;

import com.railway.payment.dto.PaymentRequest;
import com.railway.payment.dto.PaymentResponse;
import com.railway.payment.model.PaymentInfo;
import com.railway.payment.repository.PaymentInfoRepository;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class PaymentService {

    @Autowired
    private PaymentInfoRepository paymentInfoRepository;

    public PaymentResponse createPaymentIntent(PaymentRequest request) throws StripeException {
        // Step 1: Create Stripe PaymentIntent
        PaymentIntentCreateParams createParams = PaymentIntentCreateParams.builder()
                .setAmount(request.getAmount())
                .setCurrency(request.getCurrency())
                .setReceiptEmail(request.getEmail())
                .putMetadata("integration_check", "accept_a_payment")
                .putMetadata("receipt_id", request.getReceipt() != null ? request.getReceipt() : UUID.randomUUID().toString())
                .build();

        PaymentIntent paymentIntent = PaymentIntent.create(createParams);

        // Step 2: Save in MySQL
        PaymentInfo info = new PaymentInfo();
        info.setEmail(request.getEmail());
        info.setAmount(request.getAmount());
        info.setCurrency(request.getCurrency());
        info.setPaymentStatus(paymentIntent.getStatus());
        info.setStripePaymentIntentId(paymentIntent.getId());
        info.setPaymentDate(LocalDateTime.now());

        paymentInfoRepository.save(info);

        // Step 3: Return client secret
        return new PaymentResponse(paymentIntent.getClientSecret(), paymentIntent.getStatus(), paymentIntent.getId());
    }

    public String getPaymentIntentStatus(String paymentIntentId) throws StripeException {
        PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);
        return paymentIntent.getStatus();  // e.g. "succeeded", "requires_payment_method", etc.
    }
}
