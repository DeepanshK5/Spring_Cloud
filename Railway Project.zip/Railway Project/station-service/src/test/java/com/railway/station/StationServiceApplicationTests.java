package com.railway.station;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
