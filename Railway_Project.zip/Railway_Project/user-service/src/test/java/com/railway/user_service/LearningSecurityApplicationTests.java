package com.railway.user_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
