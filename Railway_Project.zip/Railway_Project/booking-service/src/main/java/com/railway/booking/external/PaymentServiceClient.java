package com.railway.booking.external;


import com.railway.booking.model.PaymentRequest;
import com.railway.booking.model.PaymentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "payment-service")
public interface PaymentServiceClient {

    @PostMapping("/api/payments/create")
    PaymentResponse createPaymentIntent(@RequestBody PaymentRequest request);

    @GetMapping("/api/payments/{paymentIntentId}")
    String paymentIntentStatus(@PathVariable String paymentIntentId);

    @PostMapping("api/payments/pay")
    String createCheckoutSession(@RequestBody PaymentRequest request);
}
